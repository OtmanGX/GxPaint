/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bdd;

import bdd.entities.User;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

/**
 *
 * @author otmangx
 */
public class Bdd {

    String url;
    String user;
    String passwd;
    Connection conn;

    /**
     * @param args the command line arguments
     */
    public Bdd(String url, String user, String password) {
        this.url = url;
        this.user = user;
        this.passwd = password;
        connect();
    }

    public Bdd() {
        this("jdbc:postgresql://localhost:5432/paint",
                "otmangx", "123");
    }

    public Connection connect() {
        try {
            Class.forName("org.postgresql.Driver");
            System.out.println("Driver O.K.");

            conn = DriverManager.getConnection(url, user, passwd);
            System.out.println("Connexion effective !");

        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }

    public ResultSet execQuery(String query) throws SQLException {
        return this.conn.createStatement().executeQuery(query);
    }
    
    public int execUpdate(String query) throws SQLException {
        return this.conn.createStatement().executeUpdate(query);
    }

    public int insert(String table, Map values) throws SQLException {

        StringBuilder columns = new StringBuilder();
        StringBuilder vals = new StringBuilder();

        for (Object col : values.keySet()) {
            columns.append(col).append(",");

            if (values.get(col) instanceof String) {
                vals.append("'").append(values.get(col)).append("',");
            } else {
                vals.append(values.get(col)).append(",");
            }
        }
        //System.out.println(columns + "\n" + vals);
        columns.setLength(columns.length() - 1);
        vals.setLength(vals.length() - 1);
        
        String query = String.format("INSERT INTO %s (%s) VALUES (%s);", table,
                columns.toString(), vals.toString());

        return this.conn.createStatement().executeUpdate(query);
    }

    public static void main(String[] args) throws IOException, SQLException, ClassNotFoundException {
        Bdd mydb = new Bdd();
        //User user = new User("OtmanGX","345");
        //Object obj = (Object)user;
        
        /*
        Vector  vec = new Vector(10);
        vec.addElement(6);
        vec.addElement(6);
        vec.addElement(6);
        vec.addElement(8);
        
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(vec);
        oos.close();
        ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
        

        PreparedStatement stm = mydb.conn.prepareStatement("insert into projects values(?, ?);");
        stm.setInt(1, 1);
        stm.setBinaryStream(2, bais);
        stm.executeUpdate();
        */
        
        
        /*
        PreparedStatement stm = mydb.conn.prepareStatement("select * from projects;");
        ResultSet res =  stm.executeQuery();
        res.next();
        ByteArrayInputStream bais=(ByteArrayInputStream) res.getBinaryStream(2);
        ObjectInputStream in = new ObjectInputStream(bais);
        Vector vec = (Vector)in.readObject();
        System.out.println(vec.get(3));
        */
        //conn.

    }

}
