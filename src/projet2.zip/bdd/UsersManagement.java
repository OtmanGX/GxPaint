/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bdd;

import bdd.dao.UsersDAO;
import bdd.entities.User;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author otmangx
 */
public class UsersManagement implements UsersDAO{
    Bdd db;
    Map values;
    String table ="users";
    
    public UsersManagement(Bdd db) {
        this.db = db;
        values = new HashMap();
    }
    
    
    @Override
    public void create(User user) throws SQLException{
        
        values.put("username", user.getUsername());
        values.put("password", user.getPassword());
        values.put("blocked", user.getBlocked());
        
        db.insert(table, values);
    }

    @Override
    public boolean isUser(User user) throws SQLException{
       
        String query = String.format("SELECT * FROM users where username = '%s' and password = '%s';"
                                    ,user.getUsername(), user.getPassword());
        ResultSet rs = db.execQuery(query);
        rs.next();
        if(rs.getRow()==1) {
            user.setBlocked(rs.getBoolean(3));
            return true;
        }
        else return false;
    }

    @Override
    public List<User> getAllUsers() throws SQLException{
        List<User> usersList = new ArrayList<User>();
        ResultSet rs = db.execQuery("SELECT * FROM users;");
		while (rs.next()) {
			User user = new User(rs.getString(1), //username
                                            rs.getString(2), //password
                                            rs.getBoolean(3)); //blocked
			usersList.add(user);
		}
        return usersList;
    }

    @Override
    public void update(User user) throws SQLException {
        String query = String.format("UPDATE USERS SET username = '%s' and password = '%s'"
                + "and blocked = '%b' where id = '%d';"
                ,user.getUsername(), user.getPassword(),user.getBlocked(), user.getID());
        db.execUpdate(query);
    }
    
}
