/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bdd;
import bdd.entities.User;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author otmangx
 */
public class Server {
    static ServerSocket server ;
    static Socket con;
    Bdd mydb;
    UsersManagement user_m;
    private int port = 5555;
    private boolean arretMarche=true;
    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public Server() {
        mydb = new Bdd();
        
        try {
            server = new ServerSocket(port);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public static void main(String[] args) throws IOException {
        
        
        
        
        Server ser = new Server();
        ser.manageConnection();
        //con = server.accept();
        //System.out.println("Client Found");
        
    }
    
    public void setArretMarche(boolean arretMarche) {
        this.arretMarche = arretMarche;
        }
    
    public void manageConnection() {
        try {
            System.out.println("En Attente : "+server.getLocalSocketAddress());
            user_m = new UsersManagement(mydb);
            user_m.isUser(new User("otman","123"));
            // Acceptation des connexions
            while (true) {
                try{
                    Socket socket = server.accept();
                    new Connexion(socket, this);
                    System.out.println("Connexion de : "
                            +socket.getRemoteSocketAddress());
                    if(!arretMarche){
                        System.out.println("Serveur arrêté. ");
                        server.close();
                        break;
                    }
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
class Connexion implements Runnable {
    private Socket socketDialogue;
    Server ser;
    public Connexion(Socket socket, Server ser) {
        this.socketDialogue = socket;
        this.ser = ser;
        Thread t = new Thread(this);
        t.start();
    }
    
    @Override
    public void run() {
        try
        {
        // Lire et afficher le message envoyé par le client
        ObjectInputStream in = new ObjectInputStream(
            socketDialogue.getInputStream());
        DataOutputStream out = new DataOutputStream(
                socketDialogue.getOutputStream());
        ObjectOutputStream outobj = new ObjectOutputStream(
                socketDialogue.getOutputStream());
        User user;
                while (true) {
                user = (User)in.readObject();
                if(this.ser.user_m.isUser(user)) {
                    if (user.getBlocked()) out.writeBytes("This user is blocked\n");
                    else {
                        out.writeBytes("\n");
                        break;
                    }
                    
                } else {
                    out.writeBytes("The username or the password is incorrect!\n");
                }
                }
                outobj.writeObject(ser.user_m.getAllUsers());
                
        
        in.close();
        out.close();
        socketDialogue.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    }

