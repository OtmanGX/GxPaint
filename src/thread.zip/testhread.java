/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author otmangx
 */

public class testhread {
    
     public static int tab[] = new int[1000];
     
    
    public static void main(String args[]) {
        for (int i=0;i<1000;i++){
            tab[i] = 0;
        }
        tab[100] = 18;
        threadfind t;
        for (int i=0;i<5;i++) {
         new threadfind(tab, 18).start();
         
        }
        
    }
}
